/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package onetapeturingmachine.Delta;

/**
 *
 * @author Thomas De Praetere
 */
public class DeltaTwo {

    private String z;
    private String A;
    private String D;

    public String getZ() {
        return z;
    }

    public void setZ(String z) {
        this.z = z;
    }

    public String getA() {
        return A;
    }

    public void setA(String A) {
        this.A = A;
    }

    public String getD() {
        return D;
    }

    public void setD(String D) {
        this.D = D;
    }

    public DeltaTwo(String z, String A, String D) {
        this.z = z;
        this.A = A;
        this.D = D;
    }
}
